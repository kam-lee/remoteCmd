<?php
date_default_timezone_set('Asia/Shanghai');
// 检查是否有GET请求
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // 检查是否有time参数
    if (!isset($_GET['time'])) {
        // 如果没有time参数，结束程序并返回空字符串
        echo '';
        exit;
    }

    // 获取time参数的值
    $time = $_GET['time'];

    // 检查是否有content参数
    $content = isset($_GET['content']) ? $_GET['content'] : null;

    // 读取inst.txt文件内容
    $instContent = file_get_contents('inst.txt');
	file_put_contents('inst.txt','');

    // 构造JSON响应
    $response = date('YmdHis').urlencode($instContent);

    // 返回JSON响应
    echo $response;
	
	//解码content，替换换行
	$dec_con = urldecode($content);
	$dec_con = str_replace(array("\r\n", "\r", "\n"), "<br />", $dec_con);
    // 记录日志
    $logFileName = date('Ymd') . '.html';
    $logContent = sprintf(
        "<p class=\"info\">GET Request Time: %s | ClaimTime: %s | Content: </p><p class=\"text\">%s</p>\n",
        date('Y-m-d H:i:s'),
        (DateTime::createFromFormat('YmdHis', $time))->format('Y-m-d H:i:s'),
        $dec_con
    );

    // 将日志内容追加到日志文件中
	if($content !=  NULL){
		if (file_exists($logFileName) == 0){
			// 文件不存在，创建文件并写入内容
			file_put_contents($logFileName, "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<title>日志".date('Ymd')."</title>\n<link rel=\"stylesheet\" href=\"log.css\">\n</head>");
		}
		file_put_contents($logFileName, $logContent, FILE_APPEND);
	}
} else {
    // 如果不是GET请求，结束程序并返回空字符串
    echo '';
    exit;
}