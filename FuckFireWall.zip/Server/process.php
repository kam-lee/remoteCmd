<?php
// 设置时区为东八区
date_default_timezone_set('Asia/Shanghai');

// 获取用户提交的指令
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['instruction'])) {
    $instruction = $_POST['instruction'];

    // 清空 inst.txt 并写入新指令
    file_put_contents('inst.txt', $instruction);
	$logFileName = date('Ymd') . '.html';
	$logContent = sprintf(
        "<p class=\"info\">GET Require Time: %s | Instruction: </p><p class=\"text\">%s</p>\n",
        date('Y-m-d H:i:s'),
        $instruction
    );
	//写入日志文件
	if($instruction !=  NULL){
		if (file_exists($logFileName) == 0){
			// 文件不存在，创建文件并写入内容
			file_put_contents($logFileName, "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<title>日志".date('Ymd')."</title>\n<link rel=\"stylesheet\" href=\"log.css\">\n</head>");
		}
		file_put_contents($logFileName, $logContent, FILE_APPEND);
	}
	// 重定向回主页
	header('Location: index.html');
	exit;
}
else{
	if (file_exists('inst.txt')) {
		echo htmlspecialchars(file_get_contents('inst.txt'));
	} else {
		echo 'file_no_exist';
	}
	exit;
}
echo "Done!"
?>